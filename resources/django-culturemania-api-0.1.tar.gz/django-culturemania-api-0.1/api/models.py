# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.


from model.profile import Profile
from model.heritage import Heritage
from model.comment import Comment
from model.vote import Vote
from model.tag import Tag




